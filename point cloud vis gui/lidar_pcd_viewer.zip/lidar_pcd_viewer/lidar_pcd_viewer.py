
from __future__ import annotations

import csv
import re
import sys
from pathlib import Path
from typing import Dict, List, Optional

import numpy as np
import open3d as o3d
import pyqtgraph.opengl as gl
from PySide6.QtCore import Qt, QThread, Signal
from PySide6.QtGui import QAction
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFileDialog,
    QFormLayout,
    QGroupBox,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSlider,
    QSpinBox,
    QSplitter,
    QStatusBar,
    QVBoxLayout,
    QWidget,
)


def natural_key(path: Path):
    """Sort frame2.pcd before frame10.pcd."""
    return [
        int(part) if part.isdigit() else part.lower()
        for part in re.split(r"(\d+)", path.name)
    ]


def intensity_or_height_colors(
    points: np.ndarray,
    colors: Optional[np.ndarray],
    mode: str,
    current_mask: Optional[np.ndarray] = None,
) -> np.ndarray:
    n = len(points)
    rgba = np.ones((n, 4), dtype=np.float32)

    if mode == "Original RGB" and colors is not None and len(colors) == n:
        rgba[:, :3] = np.clip(colors, 0.0, 1.0)
    elif mode == "Current vs neighbors" and current_mask is not None:
        rgba[:, :3] = np.array([0.25, 0.65, 1.0], dtype=np.float32)
        rgba[current_mask, :3] = np.array([1.0, 0.55, 0.10], dtype=np.float32)
    else:
        z = points[:, 2]
        z_min, z_max = float(z.min()), float(z.max())
        t = np.zeros_like(z) if z_max <= z_min else (z - z_min) / (z_max - z_min)
        # Simple blue -> cyan -> yellow height map.
        rgba[:, 0] = np.clip(1.5 * t - 0.25, 0.0, 1.0)
        rgba[:, 1] = np.clip(1.5 - np.abs(2.0 * t - 1.0), 0.0, 1.0)
        rgba[:, 2] = np.clip(1.25 - 1.5 * t, 0.0, 1.0)

    rgba[:, 3] = 1.0
    return rgba


class CloudLoader(QThread):
    loaded = Signal(object, object, object, str)
    failed = Signal(str)

    def __init__(
        self,
        files: List[Path],
        current_index: int,
        past: int,
        future: int,
        voxel_size: float,
        poses: Dict[str, np.ndarray],
    ):
        super().__init__()
        self.files = files
        self.current_index = current_index
        self.past = past
        self.future = future
        self.voxel_size = voxel_size
        self.poses = poses

    def run(self):
        try:
            start = max(0, self.current_index - self.past)
            end = min(len(self.files), self.current_index + self.future + 1)
            selected = self.files[start:end]
            current_file = self.files[self.current_index]

            point_parts = []
            color_parts = []
            mask_parts = []
            have_all_colors = True

            reference_pose = self.poses.get(current_file.name)
            if reference_pose is not None:
                world_to_reference = np.linalg.inv(reference_pose)
            else:
                world_to_reference = np.eye(4)

            missing_pose_count = 0

            for file_path in selected:
                cloud = o3d.io.read_point_cloud(str(file_path))
                points = np.asarray(cloud.points, dtype=np.float64)

                if points.size == 0:
                    continue

                pose = self.poses.get(file_path.name)
                if pose is not None and reference_pose is not None:
                    transform = world_to_reference @ pose
                    homogeneous = np.column_stack((points, np.ones(len(points))))
                    points = (transform @ homogeneous.T).T[:, :3]
                elif len(selected) > 1 and file_path != current_file:
                    missing_pose_count += 1

                point_parts.append(points.astype(np.float32))
                mask_parts.append(
                    np.full(len(points), file_path == current_file, dtype=bool)
                )

                if cloud.has_colors():
                    color_parts.append(
                        np.asarray(cloud.colors, dtype=np.float32)
                    )
                else:
                    have_all_colors = False

            if not point_parts:
                raise ValueError("The selected PCD files contain no points.")

            points = np.concatenate(point_parts, axis=0)
            current_mask = np.concatenate(mask_parts, axis=0)
            colors = (
                np.concatenate(color_parts, axis=0)
                if have_all_colors and len(color_parts) == len(point_parts)
                else None
            )

            # Downsample after accumulation. Open3D does not retain our current-frame
            # mask, so use a NumPy voxel selection to preserve it.
            if self.voxel_size > 0:
                voxels = np.floor(points / self.voxel_size).astype(np.int64)
                _, keep = np.unique(voxels, axis=0, return_index=True)
                keep.sort()
                points = points[keep]
                current_mask = current_mask[keep]
                if colors is not None:
                    colors = colors[keep]

            warning = ""
            if missing_pose_count:
                warning = (
                    f"{missing_pose_count} neighboring frame(s) had no usable pose. "
                    "They were overlaid without motion compensation."
                )

            self.loaded.emit(points, colors, current_mask, warning)
        except Exception as exc:
            self.failed.emit(str(exc))


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("LiDAR PCD Multi-Frame Viewer")
        self.resize(1350, 850)

        self.files: List[Path] = []
        self.poses: Dict[str, np.ndarray] = {}
        self.points: Optional[np.ndarray] = None
        self.original_colors: Optional[np.ndarray] = None
        self.current_mask: Optional[np.ndarray] = None
        self.scatter: Optional[gl.GLScatterPlotItem] = None
        self.worker: Optional[CloudLoader] = None

        self._build_ui()
        self._build_menu()
        self.setStatusBar(QStatusBar())

    def _build_ui(self):
        splitter = QSplitter()
        splitter.setOrientation(Qt.Horizontal)
        self.setCentralWidget(splitter)

        controls = QWidget()
        controls.setMinimumWidth(310)
        controls.setMaximumWidth(420)
        controls_layout = QVBoxLayout(controls)

        files_group = QGroupBox("Frames")
        files_form = QFormLayout(files_group)

        self.load_button = QPushButton("Load PCD files…")
        self.load_button.clicked.connect(self.load_files)
        files_form.addRow(self.load_button)

        self.file_count_label = QLabel("No frames loaded")
        self.file_count_label.setWordWrap(True)
        files_form.addRow("Dataset:", self.file_count_label)

        self.current_spin = QSpinBox()
        self.current_spin.setMinimum(1)
        self.current_spin.setMaximum(1)
        self.current_spin.valueChanged.connect(self.schedule_refresh)
        files_form.addRow("Current frame:", self.current_spin)

        self.current_name = QLabel("—")
        self.current_name.setWordWrap(True)
        files_form.addRow("Filename:", self.current_name)

        self.past_spin = QSpinBox()
        self.past_spin.setRange(0, 1000)
        self.past_spin.setValue(2)
        self.past_spin.valueChanged.connect(self.schedule_refresh)
        files_form.addRow("Past frames N:", self.past_spin)

        self.future_spin = QSpinBox()
        self.future_spin.setRange(0, 1000)
        self.future_spin.setValue(2)
        self.future_spin.valueChanged.connect(self.schedule_refresh)
        files_form.addRow("Future frames N:", self.future_spin)

        controls_layout.addWidget(files_group)

        processing_group = QGroupBox("Processing")
        processing_form = QFormLayout(processing_group)

        self.pose_button = QPushButton("Load pose CSV…")
        self.pose_button.clicked.connect(self.load_pose_csv)
        processing_form.addRow(self.pose_button)

        self.pose_label = QLabel("No poses loaded")
        self.pose_label.setWordWrap(True)
        processing_form.addRow("Alignment:", self.pose_label)

        self.voxel_spin = QDoubleSpinBox()
        self.voxel_spin.setRange(0.0, 10.0)
        self.voxel_spin.setDecimals(3)
        self.voxel_spin.setSingleStep(0.01)
        self.voxel_spin.setValue(0.05)
        self.voxel_spin.setSuffix(" m")
        processing_form.addRow("Voxel size:", self.voxel_spin)

        self.refresh_button = QPushButton("Build accumulated cloud")
        self.refresh_button.clicked.connect(self.refresh_cloud)
        processing_form.addRow(self.refresh_button)

        self.auto_refresh = QCheckBox("Refresh when frame/N changes")
        self.auto_refresh.setChecked(True)
        processing_form.addRow(self.auto_refresh)

        controls_layout.addWidget(processing_group)

        display_group = QGroupBox("Display")
        display_form = QFormLayout(display_group)

        self.color_combo = QComboBox()
        self.color_combo.addItems(
            ["Height", "Current vs neighbors", "Original RGB"]
        )
        self.color_combo.currentTextChanged.connect(self.update_scatter_style)
        display_form.addRow("Color:", self.color_combo)

        self.point_size = QSlider(Qt.Horizontal)
        self.point_size.setRange(1, 12)
        self.point_size.setValue(2)
        self.point_size.valueChanged.connect(self.update_scatter_style)
        display_form.addRow("Point size:", self.point_size)

        self.grid_check = QCheckBox("Show ground grid")
        self.grid_check.setChecked(True)
        self.grid_check.toggled.connect(self.toggle_grid)
        display_form.addRow(self.grid_check)

        self.reset_view_button = QPushButton("Reset camera")
        self.reset_view_button.clicked.connect(self.reset_camera)
        display_form.addRow(self.reset_view_button)

        controls_layout.addWidget(display_group)

        self.info_label = QLabel(
            "Load a sequence such as frame_0001.pcd … frame_0100.pcd. "
            "Frames are naturally sorted by filename."
        )
        self.info_label.setWordWrap(True)
        controls_layout.addWidget(self.info_label)
        controls_layout.addStretch(1)

        splitter.addWidget(controls)

        view_container = QWidget()
        view_layout = QVBoxLayout(view_container)
        view_layout.setContentsMargins(0, 0, 0, 0)

        self.view = gl.GLViewWidget()
        self.view.setBackgroundColor((20, 22, 26))
        self.view.opts["distance"] = 30
        self.view.opts["elevation"] = 25
        self.view.opts["azimuth"] = 45

        self.grid = gl.GLGridItem()
        self.grid.setSize(100, 100)
        self.grid.setSpacing(1, 1)
        self.view.addItem(self.grid)

        axis = gl.GLAxisItem()
        axis.setSize(3, 3, 3)
        self.view.addItem(axis)

        view_layout.addWidget(self.view)
        splitter.addWidget(view_container)
        splitter.setStretchFactor(1, 1)

    def _build_menu(self):
        file_menu = self.menuBar().addMenu("&File")

        load_action = QAction("Load PCD files…", self)
        load_action.triggered.connect(self.load_files)
        file_menu.addAction(load_action)

        poses_action = QAction("Load pose CSV…", self)
        poses_action.triggered.connect(self.load_pose_csv)
        file_menu.addAction(poses_action)

        file_menu.addSeparator()

        quit_action = QAction("Quit", self)
        quit_action.triggered.connect(self.close)
        file_menu.addAction(quit_action)

    def load_files(self):
        names, _ = QFileDialog.getOpenFileNames(
            self,
            "Select PCD frames",
            "",
            "Point clouds (*.pcd);;All files (*)",
        )
        if not names:
            return

        self.files = sorted((Path(name) for name in names), key=natural_key)
        self.current_spin.blockSignals(True)
        self.current_spin.setRange(1, len(self.files))
        self.current_spin.setValue(1)
        self.current_spin.blockSignals(False)

        self.file_count_label.setText(
            f"{len(self.files)} frame(s)\n{self.files[0].parent}"
        )
        self.update_current_name()
        self.refresh_cloud()

    def load_pose_csv(self):
        name, _ = QFileDialog.getOpenFileName(
            self,
            "Select pose CSV",
            "",
            "CSV files (*.csv);;All files (*)",
        )
        if not name:
            return

        try:
            poses: Dict[str, np.ndarray] = {}
            with open(name, "r", newline="", encoding="utf-8-sig") as handle:
                reader = csv.reader(handle)
                for row_number, row in enumerate(reader, start=1):
                    if not row or row[0].strip().startswith("#"):
                        continue

                    filename = row[0].strip()
                    values = row[1:]

                    # Allow a header row.
                    if row_number == 1 and filename.lower() in {
                        "filename", "file", "frame"
                    }:
                        continue

                    if len(values) != 16:
                        raise ValueError(
                            f"Row {row_number}: expected filename plus 16 "
                            f"matrix values, got {len(row)} columns."
                        )

                    matrix = np.asarray(
                        [float(value) for value in values],
                        dtype=np.float64,
                    ).reshape(4, 4)
                    poses[Path(filename).name] = matrix

            if not poses:
                raise ValueError("No poses were found in the CSV.")

            self.poses = poses
            self.pose_label.setText(f"{len(poses)} pose(s) loaded")
            self.refresh_cloud()
        except Exception as exc:
            QMessageBox.critical(self, "Pose CSV error", str(exc))

    def schedule_refresh(self):
        self.update_current_name()
        if self.auto_refresh.isChecked() and self.files:
            self.refresh_cloud()

    def update_current_name(self):
        if not self.files:
            self.current_name.setText("—")
            return
        index = self.current_spin.value() - 1
        if 0 <= index < len(self.files):
            self.current_name.setText(self.files[index].name)

    def refresh_cloud(self):
        if not self.files:
            return
        if self.worker is not None and self.worker.isRunning():
            return

        self.refresh_button.setEnabled(False)
        self.statusBar().showMessage("Loading and accumulating point clouds…")

        self.worker = CloudLoader(
            files=self.files,
            current_index=self.current_spin.value() - 1,
            past=self.past_spin.value(),
            future=self.future_spin.value(),
            voxel_size=self.voxel_spin.value(),
            poses=self.poses,
        )
        self.worker.loaded.connect(self.on_cloud_loaded)
        self.worker.failed.connect(self.on_cloud_failed)
        self.worker.finished.connect(
            lambda: self.refresh_button.setEnabled(True)
        )
        self.worker.start()

    def on_cloud_loaded(
        self,
        points: np.ndarray,
        colors: Optional[np.ndarray],
        current_mask: np.ndarray,
        warning: str,
    ):
        self.points = points
        self.original_colors = colors
        self.current_mask = current_mask
        self.update_scatter_style()

        frame = self.current_spin.value()
        message = f"Frame {frame}: displaying {len(points):,} points."
        if warning:
            message += " " + warning
        self.statusBar().showMessage(message)
        self.info_label.setText(message)

        if warning:
            self.info_label.setStyleSheet("color: #e0a030;")
        else:
            self.info_label.setStyleSheet("")

        self.reset_camera()

    def on_cloud_failed(self, message: str):
        self.statusBar().showMessage("Failed to load point clouds.")
        QMessageBox.critical(self, "Point-cloud error", message)

    def update_scatter_style(self):
        if self.points is None:
            return

        rgba = intensity_or_height_colors(
            self.points,
            self.original_colors,
            self.color_combo.currentText(),
            self.current_mask,
        )

        if self.scatter is not None:
            self.view.removeItem(self.scatter)

        self.scatter = gl.GLScatterPlotItem(
            pos=self.points,
            color=rgba,
            size=float(self.point_size.value()),
            pxMode=True,
        )
        self.view.addItem(self.scatter)

    def toggle_grid(self, visible: bool):
        self.grid.setVisible(visible)

    def reset_camera(self):
        if self.points is None or len(self.points) == 0:
            self.view.setCameraPosition(distance=30, elevation=25, azimuth=45)
            return

        minimum = self.points.min(axis=0)
        maximum = self.points.max(axis=0)
        center = (minimum + maximum) / 2.0
        extent = float(np.linalg.norm(maximum - minimum))
        distance = max(5.0, extent * 1.3)

        self.view.opts["center"] = center
        self.view.setCameraPosition(
            distance=distance,
            elevation=25,
            azimuth=45,
        )


def main():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec())


if __name__ == "__main__":
    main()
